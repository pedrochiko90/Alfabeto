
export const ALPHABET_CHARS: string[] = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ'.split('');
export const NUMBERS_CHARS: string[] = '0123456789'.split('');
export const ALL_DRAWABLE_CHARS: string[] = [...ALPHABET_CHARS, ...NUMBERS_CHARS];


export const LOCAL_STORAGE_KEY_ALPHABET = 'customAlphabetApp_alphabet_v2';

export const CANVAS_WIDTH = 150;
export const CANVAS_HEIGHT = 150;

export const DEFAULT_DRAW_COLOR = '#FFFFFF'; // White ink on dark canvas
export const CANVAS_BACKGROUND_COLOR = '#1E293B'; // slate-800
export const DRAW_LINE_WIDTH = 4;

export const RENDERED_LETTER_HEIGHT = 40; // Default height for letters in TextComposerView
