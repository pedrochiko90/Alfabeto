import React, { createContext, useState, useContext, useEffect, useCallback, ReactNode } from 'react';
import { DrawnAlphabet } from '../types';
import { LOCAL_STORAGE_KEY_ALPHABET, ALL_DRAWABLE_CHARS } from '../constants';

interface AlphabetContextType {
  alphabet: DrawnAlphabet;
  saveLetter: (letter: string, imageDataUrl: string) => void;
  getLetterImage: (letter: string) => string | undefined;
  clearAlphabet: () => void;
  loadAlphabet: () => void;
  isAlphabetReady: boolean;
  drawnLettersCount: number;
  exportAlphabetCode: () => string;
  importAlphabetCode: (code: string) => boolean;
}

const AlphabetContext = createContext<AlphabetContextType | undefined>(undefined);

export const AlphabetProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
  const [alphabet, setAlphabet] = useState<DrawnAlphabet>({});
  const [isLoaded, setIsLoaded] = useState(false);

  const saveAlphabetToStorage = (currentAlphabet: DrawnAlphabet) => {
    try {
      localStorage.setItem(LOCAL_STORAGE_KEY_ALPHABET, JSON.stringify(currentAlphabet));
    } catch (error) {
      console.error("Failed to save alphabet to localStorage:", error);
    }
  };

  const loadAlphabet = useCallback(() => {
    try {
      const storedAlphabet = localStorage.getItem(LOCAL_STORAGE_KEY_ALPHABET);
      if (storedAlphabet) {
        setAlphabet(JSON.parse(storedAlphabet));
      }
    } catch (error) {
      console.error("Failed to load alphabet from localStorage:", error);
      setAlphabet({});
    }
    setIsLoaded(true);
  }, []);

  useEffect(() => {
    if (!isLoaded) {
      loadAlphabet();
    }
  }, [loadAlphabet, isLoaded]);

  const saveLetter = (letter: string, imageDataUrl: string) => {
    setAlphabet(prevAlphabet => {
      const newAlphabet = { ...prevAlphabet, [letter.toUpperCase()]: imageDataUrl };
      saveAlphabetToStorage(newAlphabet);
      return newAlphabet;
    });
  };

  const getLetterImage = (letter: string): string | undefined => {
    return alphabet[letter.toUpperCase()];
  };

  const clearAlphabet = () => {
    setAlphabet({});
    localStorage.removeItem(LOCAL_STORAGE_KEY_ALPHABET);
  };
  
  const drawnLettersCount = Object.keys(alphabet).filter(key => ALL_DRAWABLE_CHARS.includes(key.toUpperCase())).length;
  const isAlphabetReady = drawnLettersCount > 0;

  const exportAlphabetCode = (): string => {
    try {
      const jsonString = JSON.stringify(alphabet);
      return btoa(jsonString); // Base64 encode
    } catch (error) {
      console.error("Failed to export alphabet code:", error);
      return "";
    }
  };

  const importAlphabetCode = (code: string): boolean => {
    try {
      const jsonString = atob(code); // Base64 decode
      const importedAlphabet = JSON.parse(jsonString) as DrawnAlphabet;
      // Basic validation: check if it's an object (further checks could be added)
      if (typeof importedAlphabet === 'object' && importedAlphabet !== null) {
        setAlphabet(importedAlphabet);
        saveAlphabetToStorage(importedAlphabet);
        return true;
      }
      return false;
    } catch (error) {
      console.error("Failed to import alphabet code:", error);
      return false;
    }
  };

  return (
    <AlphabetContext.Provider value={{ 
        alphabet, 
        saveLetter, 
        getLetterImage, 
        clearAlphabet, 
        loadAlphabet, 
        isAlphabetReady, 
        drawnLettersCount,
        exportAlphabetCode,
        importAlphabetCode
    }}>
      {children}
    </AlphabetContext.Provider>
  );
};

export const useAlphabet = (): AlphabetContextType => {
  const context = useContext(AlphabetContext);
  if (!context) {
    throw new Error('useAlphabet must be used within an AlphabetProvider');
  }
  return context;
};
