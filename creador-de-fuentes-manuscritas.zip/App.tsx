import React, { useState } from 'react';
import { AlphabetProvider } from './context/AlphabetContext';
import AlphabetDrawingView from './components/AlphabetDrawingView';
import TextComposerView from './components/TextComposerView';
import { GithubIcon } from './components/Icons';
import { es } from './localization';

const App: React.FC = () => {
  const [currentView, setCurrentView] = useState<'drawing' | 'composing'>('drawing');

  return (
    <AlphabetProvider>
      <div className="min-h-screen bg-gradient-to-br from-slate-900 to-slate-700 text-slate-100 flex flex-col items-center p-4 selection:bg-sky-500 selection:text-white">
        <header className="w-full max-w-4xl mb-8 text-center">
          <h1 className="text-4xl sm:text-5xl font-bold text-transparent bg-clip-text bg-gradient-to-r from-sky-400 to-cyan-300 py-2">
            {es.appName}
          </h1>
          <p className="text-slate-400 mt-2 text-sm sm:text-base">
            {es.appDescription}
          </p>
        </header>

        <main className="w-full max-w-4xl bg-slate-800 shadow-2xl rounded-lg p-6 sm:p-8">
          {currentView === 'drawing' && (
            <AlphabetDrawingView onCompose={() => setCurrentView('composing')} />
          )}
          {currentView === 'composing' && (
            <TextComposerView onEditAlphabet={() => setCurrentView('drawing')} />
          )}
        </main>
        <footer className="w-full max-w-4xl mt-12 text-center text-slate-500 text-sm">
          <p>{es.footerSlogan}</p>
          <a
            href={es.gitHubRepoUrl}
            target="_blank"
            rel="noopener noreferrer"
            className="inline-flex items-center text-slate-400 hover:text-sky-400 transition-colors mt-2"
          >
            <GithubIcon className="w-5 h-5 mr-2" />
            {es.viewOnGitHub}
          </a>
        </footer>
      </div>
    </AlphabetProvider>
  );
};

export default App;
