
import { Buffer } from 'buffer'; // Parcel might need this for process polyfill
globalThis.Buffer = Buffer; // Make Buffer global for the process polyfill
import process from 'process'; // Import the process polyfill

// Augment the globalThis type to include 'process'
declare global {
  namespace NodeJS {
    interface Global {
      process: typeof process;
    }
  }
  // eslint-disable-next-line no-var
  var process: typeof process; // If also using it directly as 'process'
}
globalThis.process = process; // Make process global


import React from 'react';
import ReactDOM from 'react-dom/client';
import App from './App';

const rootElement = document.getElementById('root');
if (!rootElement) {
  throw new Error("Could not find root element to mount to");
}

const root = ReactDOM.createRoot(rootElement);
root.render(
  <React.StrictMode>
    <App />
  </React.StrictMode>
);