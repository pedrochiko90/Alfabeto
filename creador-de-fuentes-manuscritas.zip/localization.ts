export const es = {
  appName: "Creador de Fuentes Manuscritas",
  appDescription: "Dibuja tu alfabeto único y da vida a tu escritura en texto digital.",
  viewOnGitHub: "Ver en GitHub",
  footerSlogan: "Crea tu fuente personal, letra por letra.",
  gitHubRepoUrl: "https://github.com/google/ai-prompt-gallery", // Replace with actual link

  // AlphabetDrawingView
  step1Title: "Paso 1: Dibuja Tus Caracteres",
  step1Description: "Haz clic en un carácter a continuación para abrir el panel de dibujo. Guarda cada uno para construir tu fuente única.",
  drawnOutOf: "dibujados de",
  lettersAZ: "Letras (A-Z)",
  numbers09: "Números (0-9)",
  clearEntireFont: "Limpiar Fuente Completa",
  confirmClearFont: "¿Estás seguro de que quieres borrar todo tu alfabeto manuscrito? Esta acción no se puede deshacer.",
  useMyFont: "¡Usar Mi Fuente!",
  drawAtLeastOneCharacter: "Dibuja al menos un carácter para continuar.",
  exportAlphabet: "Exportar Alfabeto",
  importAlphabetTitle: "Importar Alfabeto",
  pasteCodeHere: "Pega tu código aquí...",
  importButton: "Importar",
  copyCodeButton: "Copiar Código",
  codeCopied: "¡Código copiado al portapapeles!",
  alphabetImported: "¡Alfabeto importado con éxito!",
  alphabetImportError: "Error al importar el alfabeto. El código podría ser inválido o estar corrupto.",
  yourAlphabetCode: "Tu Código de Alfabeto (copia esto):",


  // DrawingBoard
  drawCharacter: (char: string) => `Dibujar '${char}'`,
  drawCharacterDescription: "Crea el aspecto perfecto para este carácter.",
  clear: "Limpiar",
  saveLetter: "Guardar Letra",
  closeDrawingBoard: "Cerrar panel de dibujo",

  // TextComposerView
  step2Title: "Paso 2: Compón Tu Texto",
  step2Description: "Escribe en el cuadro de abajo. ¡Tu texto se representará usando tu fuente manuscrita única!",
  textInputPlaceholder: "Comienza a escribir tu mensaje aquí...",
  yourHandwrittenText: "Tu Texto Manuscrito:",
  backToEditingFont: "Volver a Editar Mi Fuente",
  noFontFoundTitle: "¡No se Encontró Ninguna Fuente!",
  noFontFoundDescription: "Aún no has dibujado ningún carácter. Por favor, vuelve y crea tu alfabeto primero.",
  drawMyAlphabet: "Dibujar Mi Alfabeto",
  letterSpacingLabel: "Espaciado entre letras:",
  currentLetterSpacing: (spacing: number) => `${spacing}px`,


  // LetterThumbnail
  editLetter: (letter: string) => `Editar letra ${letter}`,
  drawnLetterAlt: (letter: string) => `Letra dibujada ${letter}`,

  // TextRenderer
  textRendererPlaceholder: "Tu obra maestra aparecerá aquí...",
};