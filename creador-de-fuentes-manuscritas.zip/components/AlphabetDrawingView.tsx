
import React, { useState, useCallback } from 'react';
import { useAlphabet } from '../context/AlphabetContext';
import DrawingBoard from './DrawingBoard';
import { LetterThumbnail } from './LetterThumbnail';
import { ALL_DRAWABLE_CHARS, ALPHABET_CHARS, NUMBERS_CHARS } from '../constants';
import { EditIcon, SparklesIcon, TrashIcon, UploadIcon, DownloadIcon, ClipboardCopyIcon } from './Icons';
import { es } from '../localization';

interface AlphabetDrawingViewProps {
  onCompose: () => void;
}

interface RenderCharacterSectionProps {
    title: string;
    chars: string[];
    onSelect: (letter: string) => void;
    getLetterImage: (letter: string) => string | undefined;
    selectedLetter: string | null;
}

const RenderCharacterSection: React.FC<RenderCharacterSectionProps> = ({ title, chars, onSelect, getLetterImage, selectedLetter }) => (
    <div className="mb-6">
        <h3 className="text-lg font-medium text-slate-300 mb-3">{title}</h3>
        <div className="flex flex-wrap gap-2">
            {chars.map((char) => (
                <LetterThumbnail
                    key={char}
                    letter={char}
                    imageDataUrl={getLetterImage(char)}
                    onClick={() => onSelect(char)}
                    isSelected={selectedLetter === char}
                    size={50}
                />
            ))}
        </div>
    </div>
);

const AlphabetDrawingView: React.FC<AlphabetDrawingViewProps> = ({ onCompose }) => {
  const { 
    alphabet, 
    saveLetter, 
    getLetterImage, 
    clearAlphabet, 
    drawnLettersCount,
    exportAlphabetCode,
    importAlphabetCode
  } = useAlphabet();
  const [selectedLetter, setSelectedLetter] = useState<string | null>(null);
  const [showExportCode, setShowExportCode] = useState(false);
  const [alphabetCode, setAlphabetCode] = useState('');
  const [importCode, setImportCode] = useState('');
  const [notification, setNotification] = useState<string | null>(null);

  const handleSelectLetter = useCallback((letter: string) => {
    setSelectedLetter(letter);
  }, []);

  const handleSaveLetter = (letter: string, imageDataUrl: string) => {
    saveLetter(letter, imageDataUrl);
    // Optionally close board or keep open for quick edits
    // setSelectedLetter(null); 
  };
  
  const handleCloseDrawingBoard = () => {
    setSelectedLetter(null);
  };

  const handleExportClick = () => {
    const code = exportAlphabetCode();
    setAlphabetCode(code);
    setShowExportCode(true);
    setNotification(null); // Clear previous notifications
  };

  const handleCopyCode = async () => {
    if (alphabetCode) {
      try {
        await navigator.clipboard.writeText(alphabetCode);
        setNotification(es.codeCopied);
      } catch (err) {
        console.error('Failed to copy code: ', err);
        setNotification("Error al copiar. Intenta manualmente."); // User-friendly error
      } finally {
        setTimeout(() => setNotification(null), 3000);
      }
    }
  };

  const handleImportClick = () => {
    if (importCode.trim() === '') {
        setNotification(es.alphabetImportError); // Or a specific message for empty code
        setTimeout(() => setNotification(null), 3000);
        return;
    }
    const success = importAlphabetCode(importCode);
    if (success) {
      setNotification(es.alphabetImported);
      setImportCode('');
      setShowExportCode(false); 
    } else {
      setNotification(es.alphabetImportError);
    }
    setTimeout(() => setNotification(null), 4000);
  };

  const progressPercentage = ALL_DRAWABLE_CHARS.length > 0 ? (drawnLettersCount / ALL_DRAWABLE_CHARS.length) * 100 : 0;

  return (
    <div className="space-y-8">
      <div>
        <div className="flex justify-between items-center mb-2">
            <h2 className="text-2xl font-semibold text-sky-400 flex items-center">
                <EditIcon className="w-7 h-7 mr-3 text-sky-500" />
                {es.step1Title}
            </h2>
            <span className="text-sm text-slate-400 tabular-nums">{drawnLettersCount} / {ALL_DRAWABLE_CHARS.length} {es.drawnOutOf}</span>
        </div>
        <p className="text-slate-400 mb-3">
          {es.step1Description}
        </p>
        <div className="w-full bg-slate-700 rounded-full h-2.5 mb-6 shadow-inner">
            <div 
                className="bg-sky-500 h-2.5 rounded-full transition-all duration-500 ease-out" 
                style={{ width: `${progressPercentage}%`}}
                role="progressbar"
                aria-valuenow={Math.round(progressPercentage)}
                aria-valuemin={0}
                aria-valuemax={100}
                aria-label={es.appName + " progress"} // More specific label
            ></div>
        </div>

        <RenderCharacterSection title={es.lettersAZ} chars={ALPHABET_CHARS} onSelect={handleSelectLetter} getLetterImage={getLetterImage} selectedLetter={selectedLetter} />
        <RenderCharacterSection title={es.numbers09} chars={NUMBERS_CHARS} onSelect={handleSelectLetter} getLetterImage={getLetterImage} selectedLetter={selectedLetter} />
      </div>

      {selectedLetter && (
        <DrawingBoard
          letterToDraw={selectedLetter}
          onSave={handleSaveLetter}
          initialImageDataUrl={getLetterImage(selectedLetter)}
          onClose={handleCloseDrawingBoard}
        />
      )}

      {/* Export/Import Section */}
      <div className="mt-8 pt-6 border-t border-slate-700 space-y-6">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-x-6 gap-y-8">
            {/* Export */}
            <div className="space-y-3">
                <h3 className="text-lg font-medium text-slate-300 flex items-center">
                    <DownloadIcon className="w-5 h-5 mr-2 text-sky-400" /> {es.exportAlphabet}
                </h3>
                <button
                    onClick={handleExportClick}
                    disabled={drawnLettersCount === 0}
                    className="w-full flex items-center justify-center px-6 py-3 border border-slate-600 text-base font-medium rounded-md text-slate-300 bg-slate-700 hover:bg-slate-600 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-offset-slate-800 focus:ring-sky-500 disabled:opacity-50 disabled:cursor-not-allowed transition-colors"
                >
                    {es.exportAlphabet}
                </button>
                {showExportCode && alphabetCode && (
                    <div className="mt-2 p-3 bg-slate-900 rounded-md shadow space-y-2">
                        <label htmlFor="exportCodeArea" className="sr-only">{es.yourAlphabetCode}</label>
                        <textarea
                            id="exportCodeArea"
                            readOnly
                            value={alphabetCode}
                            className="w-full h-28 p-2.5 bg-slate-800 border border-slate-600 rounded-md text-slate-200 focus:ring-2 focus:ring-sky-500 focus:border-sky-500 resize-none"
                            aria-label={es.yourAlphabetCode}
                        ></textarea>
                        <button
                            onClick={handleCopyCode}
                            className="w-full flex items-center justify-center px-4 py-2 border border-transparent text-sm font-medium rounded-md text-white bg-sky-600 hover:bg-sky-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-offset-slate-900 focus:ring-sky-500 transition-colors"
                        >
                            <ClipboardCopyIcon className="w-4 h-4 mr-2" />
                            {es.copyCodeButton}
                        </button>
                    </div>
                )}
            </div>

            {/* Import */}
            <div className="space-y-3">
                <h3 className="text-lg font-medium text-slate-300 flex items-center">
                    <UploadIcon className="w-5 h-5 mr-2 text-sky-400" /> {es.importAlphabetTitle}
                </h3>
                <textarea
                    value={importCode}
                    onChange={(e) => setImportCode(e.target.value)}
                    placeholder={es.pasteCodeHere}
                    className="w-full h-28 p-2.5 bg-slate-700 border border-slate-600 rounded-md text-slate-100 focus:ring-2 focus:ring-sky-500 focus:border-sky-500 resize-none placeholder-slate-400"
                    aria-label={es.importAlphabetTitle}
                />
                <button
                    onClick={handleImportClick}
                    disabled={!importCode.trim()}
                    className="w-full flex items-center justify-center px-6 py-3 border border-transparent text-base font-medium rounded-md text-white bg-emerald-600 hover:bg-emerald-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-offset-slate-800 focus:ring-emerald-500 disabled:opacity-50 disabled:cursor-not-allowed transition-colors"
                >
                    {es.importButton}
                </button>
            </div>
        </div>
        
        {notification && (
            <div className={`mt-4 p-3 rounded-md text-sm font-medium ${notification.toLowerCase().includes('error') ? 'bg-red-500/20 text-red-300 border border-red-500/30' : 'bg-green-500/20 text-green-300 border border-green-500/30'}`}
                 role="alert">
                {notification}
            </div>
        )}
      </div>

      {/* Actions: Clear Alphabet & Compose */}
      <div className="mt-10 pt-6 border-t border-slate-700 flex flex-col sm:flex-row justify-between items-center space-y-4 sm:space-y-0 sm:space-x-4">
        <button
          onClick={() => {
            if (window.confirm(es.confirmClearFont)) {
              clearAlphabet();
              setShowExportCode(false);
              setAlphabetCode('');
              setImportCode('');
              setNotification(null);
            }
          }}
          disabled={drawnLettersCount === 0}
          className="w-full sm:w-auto flex items-center justify-center px-6 py-3 border border-red-500/50 text-base font-medium rounded-md text-red-400 hover:bg-red-500 hover:text-white disabled:opacity-50 disabled:cursor-not-allowed transition-colors focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-offset-slate-800 focus:ring-red-500"
        >
          <TrashIcon className="w-5 h-5 mr-2" />
          {es.clearEntireFont}
        </button>
        <button
          onClick={onCompose}
          disabled={drawnLettersCount === 0}
          className="w-full sm:w-auto flex items-center justify-center px-8 py-3.5 border border-transparent text-base font-bold rounded-md text-slate-900 bg-sky-400 hover:bg-sky-500 disabled:opacity-60 disabled:cursor-not-allowed transition-transform duration-150 ease-in-out hover:scale-105 shadow-lg focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-offset-slate-800 focus:ring-sky-500"
        >
          {es.useMyFont}
          <SparklesIcon className="w-5 h-5 ml-2" />
        </button>
      </div>
      {drawnLettersCount === 0 && !selectedLetter && (
         <p className="text-center text-amber-400 text-sm mt-4" role="status">{es.drawAtLeastOneCharacter}</p>
      )}
    </div>
  );
};

export default AlphabetDrawingView;
