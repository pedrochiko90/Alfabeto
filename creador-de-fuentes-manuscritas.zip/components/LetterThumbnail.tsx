
import React from 'react';

interface LetterThumbnailProps {
  letter: string;
  imageDataUrl?: string;
  onClick: () => void;
  isSelected?: boolean; // Optional: if this thumbnail represents the currently selected drawing target
  size?: number;
}

export const LetterThumbnail: React.FC<LetterThumbnailProps> = ({
  letter,
  imageDataUrl,
  onClick,
  isSelected = false,
  size = 60,
}) => {
  return (
    <button
      onClick={onClick}
      className={`border-2 p-1 m-1 flex items-center justify-center transition-all duration-150 ease-in-out
                  ${isSelected ? 'border-sky-500 ring-2 ring-sky-400 scale-105 shadow-lg' : 'border-slate-600 hover:border-sky-500'}
                  bg-slate-700 hover:bg-slate-600 rounded-lg shadow-md hover:shadow-lg`}
      style={{ width: `${size}px`, height: `${size}px` }}
      title={`Draw or edit letter ${letter}`}
      aria-label={`Edit letter ${letter}`}
    >
      {imageDataUrl ? (
        <img src={imageDataUrl} alt={`Drawn letter ${letter}`} className="max-w-full max-h-full object-contain p-1" />
      ) : (
        <span className="text-2xl text-slate-400 font-semibold">{letter}</span>
      )}
    </button>
  );
};
