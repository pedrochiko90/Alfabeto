import React, { useState, useEffect } from 'react';
import { useAlphabet } from '../context/AlphabetContext';
import { TextRenderer } from './TextRenderer';
import { RENDERED_LETTER_HEIGHT } from '../constants';
import { EditIcon, TypeIcon, SparklesIcon, AlertTriangleIcon } from './Icons';
import { es } from '../localization';

interface TextComposerViewProps {
  onEditAlphabet: () => void;
}

const DEFAULT_LETTER_SPACING = 1; // Default spacing in pixels

const TextComposerView: React.FC<TextComposerViewProps> = ({ onEditAlphabet }) => {
  const { alphabet, isAlphabetReady, loadAlphabet } = useAlphabet();
  const [text, setText] = useState<string>('');
  const [letterSpacing, setLetterSpacing] = useState<number>(DEFAULT_LETTER_SPACING);

  useEffect(() => {
    // Ensure alphabet is loaded if navigating directly or on refresh
    loadAlphabet();
  }, [loadAlphabet]);

  if (!isAlphabetReady) {
    return (
      <div className="text-center p-8 bg-slate-700 rounded-lg shadow-inner">
        <AlertTriangleIcon className="w-16 h-16 text-amber-400 mx-auto mb-4" />
        <h2 className="text-2xl font-semibold text-amber-300 mb-3">{es.noFontFoundTitle}</h2>
        <p className="text-slate-300 mb-6">
          {es.noFontFoundDescription}
        </p>
        <button
          onClick={onEditAlphabet}
          className="px-6 py-3 bg-sky-500 hover:bg-sky-600 text-white font-semibold rounded-md shadow-md transition-colors duration-150 ease-in-out flex items-center justify-center mx-auto"
        >
          <EditIcon className="w-5 h-5 mr-2" />
          {es.drawMyAlphabet}
        </button>
      </div>
    );
  }

  return (
    <div className="space-y-8">
      <div>
        <h2 className="text-2xl font-semibold text-sky-400 mb-1 flex items-center">
            <TypeIcon className="w-7 h-7 mr-3 text-sky-500" />
            {es.step2Title}
        </h2>
        <p className="text-slate-400 mb-4">
          {es.step2Description}
        </p>
        <textarea
          value={text}
          onChange={(e) => setText(e.target.value)}
          placeholder={es.textInputPlaceholder}
          className="w-full h-32 p-4 border border-slate-600 rounded-md bg-slate-700 text-slate-100 focus:ring-2 focus:ring-sky-500 focus:border-sky-500 transition-colors shadow"
          aria-label="Text input area"
        />
      </div>

      <div className="space-y-4">
        <h3 className="text-xl font-semibold text-slate-300 flex items-center">
            <SparklesIcon className="w-6 h-6 mr-2 text-slate-400" />
            {es.yourHandwrittenText}
        </h3>
        
        <div className="p-4 bg-slate-700/30 rounded-md">
            <label htmlFor="letterSpacingSlider" className="block text-sm font-medium text-slate-300 mb-1">
              {es.letterSpacingLabel} <span className="font-mono text-sky-400">{es.currentLetterSpacing(letterSpacing)}</span>
            </label>
            <input
                id="letterSpacingSlider"
                type="range"
                min="0"
                max="20" // Max 20px spacing
                value={letterSpacing}
                onChange={(e) => setLetterSpacing(Number(e.target.value))}
                className="w-full h-2 bg-slate-600 rounded-lg appearance-none cursor-pointer accent-sky-500"
                aria-label={es.letterSpacingLabel}
            />
        </div>

        <TextRenderer 
            text={text} 
            alphabet={alphabet} 
            letterHeight={RENDERED_LETTER_HEIGHT}
            letterSpacing={letterSpacing} 
        />
      </div>

      <div className="mt-8 pt-6 border-t border-slate-700">
        <button
          onClick={onEditAlphabet}
          className="flex items-center justify-center w-full sm:w-auto px-6 py-3 border border-slate-600 text-base font-medium rounded-md text-sky-400 hover:text-slate-100 hover:bg-sky-500 hover:border-sky-500 transition-colors shadow-sm"
        >
          <EditIcon className="w-5 h-5 mr-2" />
          {es.backToEditingFont}
        </button>
      </div>
    </div>
  );
};

export default TextComposerView;