
import React, { useRef, useEffect, useState, useCallback } from 'react';
import { CANVAS_WIDTH, CANVAS_HEIGHT, DEFAULT_DRAW_COLOR, DRAW_LINE_WIDTH, CANVAS_BACKGROUND_COLOR } from '../constants';
import { SaveIcon, TrashIcon, XCircleIcon } from './Icons';
import { es } from '../localization';

interface DrawingBoardProps {
  letterToDraw: string;
  onSave: (letter: string, imageDataUrl: string) => void;
  initialImageDataUrl?: string;
  onClose: () => void;
}

// Helper function to convert hex color to RGB object
const hexToRgb = (hex: string): { r: number; g: number; b: number } | null => {
  const result = /^#?([a-f\d]{2})([a-f\d]{2})([a-f\d]{2})$/i.exec(hex);
  return result
    ? {
        r: parseInt(result[1], 16),
        g: parseInt(result[2], 16),
        b: parseInt(result[3], 16),
      }
    : null;
};

const DrawingBoard: React.FC<DrawingBoardProps> = ({ letterToDraw, onSave, initialImageDataUrl, onClose }) => {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const [isDrawing, setIsDrawing] = useState(false);
  const [ctx, setCtx] = useState<CanvasRenderingContext2D | null>(null);

  const clearCanvas = useCallback(() => {
    if (ctx && canvasRef.current) {
      // The fillRect coordinates are interpreted by the scaled context.
      // So, filling (0,0) to (CANVAS_WIDTH, CANVAS_HEIGHT) covers the logical canvas area.
      ctx.fillStyle = CANVAS_BACKGROUND_COLOR;
      ctx.fillRect(0, 0, CANVAS_WIDTH, CANVAS_HEIGHT);
    }
  }, [ctx]);

  useEffect(() => {
    if (canvasRef.current) {
      const canvas = canvasRef.current;
      // Set actual canvas element size (backing store) for HDPI
      canvas.width = CANVAS_WIDTH * 2;
      canvas.height = CANVAS_HEIGHT * 2;
      // Set display size using CSS
      canvas.style.width = `${CANVAS_WIDTH}px`;
      canvas.style.height = `${CANVAS_HEIGHT}px`;

      const context = canvas.getContext('2d');
      if (context) {
        context.scale(2, 2); // Scale context for drawing at higher resolution
        context.lineCap = 'round';
        context.lineJoin = 'round';
        context.strokeStyle = DEFAULT_DRAW_COLOR;
        context.lineWidth = DRAW_LINE_WIDTH;
        setCtx(context);
        
        // Initial clear and load image
        context.fillStyle = CANVAS_BACKGROUND_COLOR;
        context.fillRect(0, 0, CANVAS_WIDTH, CANVAS_HEIGHT);

        if (initialImageDataUrl) {
          const img = new Image();
          img.onload = () => {
            context.drawImage(img, 0, 0, CANVAS_WIDTH, CANVAS_HEIGHT); // Draw image to fill logical canvas
          };
          img.src = initialImageDataUrl;
        }
      }
    }
  }, []); // Only run once on mount for initial setup
  
  // Re-clear and re-draw if letterToDraw changes and new initialImageDataUrl is provided.
   useEffect(() => {
    if (ctx) { // Check if ctx is initialized
        clearCanvas(); // Clear first
        if (initialImageDataUrl) {
            const img = new Image();
            img.onload = () => {
                // Draw image respecting the scaled context, to fill the logical canvas area.
                ctx.drawImage(img, 0, 0, CANVAS_WIDTH, CANVAS_HEIGHT);
            };
            img.src = initialImageDataUrl;
        }
    }
  }, [letterToDraw, initialImageDataUrl, ctx, clearCanvas]);


  const getCoordinates = (event: React.MouseEvent | React.TouchEvent): { x: number; y: number } | null => {
    if (!canvasRef.current) return null;
    const canvas = canvasRef.current;
    const rect = canvas.getBoundingClientRect();
    let x, y;

    if (event.nativeEvent instanceof MouseEvent) {
      x = event.nativeEvent.clientX - rect.left;
      y = event.nativeEvent.clientY - rect.top;
    } else if (event.nativeEvent instanceof TouchEvent && event.nativeEvent.touches.length > 0) {
      x = event.nativeEvent.touches[0].clientX - rect.left;
      y = event.nativeEvent.touches[0].clientY - rect.top;
    } else {
      return null;
    }
    // Coordinates are relative to the CSS-scaled canvas, which is what the drawing functions expect
    // due to the context.scale(2,2) call.
    return { x, y };
  };

  const startDrawing = useCallback((event: React.MouseEvent | React.TouchEvent) => {
    const coords = getCoordinates(event);
    if (!ctx || !coords) return;
    setIsDrawing(true);
    ctx.beginPath();
    ctx.moveTo(coords.x, coords.y);
    ctx.fillStyle = DEFAULT_DRAW_COLOR;
    ctx.fillRect(coords.x - DRAW_LINE_WIDTH / 2, coords.y - DRAW_LINE_WIDTH / 2, DRAW_LINE_WIDTH, DRAW_LINE_WIDTH);
  }, [ctx]);

  const draw = useCallback((event: React.MouseEvent | React.TouchEvent) => {
    if (!isDrawing || !ctx) return;
    event.preventDefault(); // Prevent scrolling on touch devices
    const coords = getCoordinates(event);
    if (!coords) return;
    
    ctx.lineTo(coords.x, coords.y);
    ctx.stroke();
  }, [isDrawing, ctx]);

  const stopDrawing = useCallback(() => {
    if (!ctx) return;
    ctx.closePath();
    setIsDrawing(false);
  }, [ctx]);

  const handleSave = () => {
    const canvas = canvasRef.current;
    if (canvas && ctx) {
      const actualCanvasWidth = canvas.width; // This is CANVAS_WIDTH * 2
      const actualCanvasHeight = canvas.height; // This is CANVAS_HEIGHT * 2
      
      const imageData = ctx.getImageData(0, 0, actualCanvasWidth, actualCanvasHeight);
      const data = imageData.data;
      
      const bgColorRgb = hexToRgb(CANVAS_BACKGROUND_COLOR);
      if (!bgColorRgb) {
        console.error("Invalid background color format for trimming.");
        // Fallback to un-trimmed image if color conversion fails
        const unTrimmedImageDataUrl = canvas.toDataURL('image/png');
        onSave(letterToDraw, unTrimmedImageDataUrl);
        onClose();
        return;
      }

      let minX = actualCanvasWidth;
      let minY = actualCanvasHeight;
      let maxX = 0;
      let maxY = 0;
      let foundPixel = false;

      for (let y = 0; y < actualCanvasHeight; y++) {
        for (let x = 0; x < actualCanvasWidth; x++) {
          const i = (y * actualCanvasWidth + x) * 4;
          const r = data[i];
          const g = data[i+1];
          const b = data[i+2];
          const a = data[i+3];

          // Pixel is part of drawing if alpha > 0 and color is not background
          if (a > 0 && (r !== bgColorRgb.r || g !== bgColorRgb.g || b !== bgColorRgb.b)) {
            if (x < minX) minX = x;
            if (x > maxX) maxX = x;
            if (y < minY) minY = y;
            if (y > maxY) maxY = y;
            foundPixel = true;
          }
        }
      }

      let finalImageDataUrl;
      if (!foundPixel) {
        // Canvas is empty (or only background color). Create a 1x1 transparent PNG.
        const tempEmptyCanvas = document.createElement('canvas');
        tempEmptyCanvas.width = 1;
        tempEmptyCanvas.height = 1;
        finalImageDataUrl = tempEmptyCanvas.toDataURL('image/png');
      } else {
        // Add a small padding to prevent clipping at the very edge of strokes
        const padding = DRAW_LINE_WIDTH * 2; // Padding in scaled pixels
        minX = Math.max(0, minX - padding);
        minY = Math.max(0, minY - padding);
        maxX = Math.min(actualCanvasWidth - 1, maxX + padding);
        maxY = Math.min(actualCanvasHeight - 1, maxY + padding);

        const trimWidth = maxX - minX + 1;
        const trimHeight = maxY - minY + 1;

        if (trimWidth <= 0 || trimHeight <= 0) {
             // Should not happen if foundPixel is true, but as a safeguard
            const tempEmptyCanvas = document.createElement('canvas');
            tempEmptyCanvas.width = 1;
            tempEmptyCanvas.height = 1;
            finalImageDataUrl = tempEmptyCanvas.toDataURL('image/png');
        } else {
            const tempCanvas = document.createElement('canvas');
            tempCanvas.width = trimWidth;
            tempCanvas.height = trimHeight;
            const tempCtx = tempCanvas.getContext('2d');

            if (tempCtx) {
              tempCtx.drawImage(
                canvas,       // Source: original canvas (high-res drawing)
                minX, minY,   // Source X, Y (top-left of bounding box in original)
                trimWidth, trimHeight, // Source W, H (size of bounding box in original)
                0, 0,         // Destination X, Y (top-left of temp canvas)
                trimWidth, trimHeight  // Destination W, H (fill temp canvas)
              );
              finalImageDataUrl = tempCanvas.toDataURL('image/png');
            } else {
              // Fallback if tempCtx fails to initialize
              console.error("Failed to create temporary canvas context for trimming.");
              finalImageDataUrl = canvas.toDataURL('image/png'); // Save un-trimmed
            }
        }
      }
      onSave(letterToDraw, finalImageDataUrl);
      onClose();
    }
  };

  return (
    <div className="fixed inset-0 bg-slate-900 bg-opacity-75 backdrop-blur-sm flex items-center justify-center p-4 z-50" aria-modal="true" role="dialog">
      <div className="bg-slate-700 p-6 rounded-lg shadow-xl relative w-auto">
        <button
          onClick={onClose}
          className="absolute top-3 right-3 text-slate-400 hover:text-sky-400 transition-colors"
          aria-label={es.closeDrawingBoard}
        >
          <XCircleIcon className="w-8 h-8" />
        </button>
        <h3 className="text-3xl font-bold text-center mb-1 text-sky-400">{es.drawCharacter(letterToDraw)}</h3>
        <p className="text-slate-400 text-center mb-4">{es.drawCharacterDescription}</p>
        
        <canvas
          ref={canvasRef}
          onMouseDown={startDrawing}
          onMouseMove={draw}
          onMouseUp={stopDrawing}
          onMouseLeave={stopDrawing}
          onTouchStart={startDrawing}
          onTouchMove={draw}
          onTouchEnd={stopDrawing}
          className="border-2 border-slate-500 rounded-md cursor-crosshair shadow-inner bg-slate-800 touch-none"
          // Actual width and height are set via canvas.width/height in useEffect for HDPI.
          // CSS style sets the display size.
        ></canvas>

        <div className="mt-6 flex justify-around space-x-3">
          <button
            onClick={clearCanvas}
            className="flex-1 bg-red-600 hover:bg-red-700 text-white font-semibold py-3 px-4 rounded-md shadow-md transition-colors duration-150 ease-in-out flex items-center justify-center"
          >
            <TrashIcon className="w-5 h-5 mr-2" />
            {es.clear}
          </button>
          <button
            onClick={handleSave}
            className="flex-1 bg-sky-500 hover:bg-sky-600 text-white font-semibold py-3 px-4 rounded-md shadow-md transition-colors duration-150 ease-in-out flex items-center justify-center"
          >
            <SaveIcon className="w-5 h-5 mr-2" />
            {es.saveLetter}
          </button>
        </div>
      </div>
    </div>
  );
};

export default DrawingBoard;
