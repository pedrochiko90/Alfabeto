import React from 'react';
import { DrawnAlphabet } from '../types';
import { RENDERED_LETTER_HEIGHT } from '../constants';
import { es } from '../localization';

interface TextRendererProps {
  text: string;
  alphabet: DrawnAlphabet;
  letterHeight?: number;
  letterSpacing?: number; // Added letterSpacing prop
}

export const TextRenderer: React.FC<TextRendererProps> = ({ 
  text, 
  alphabet, 
  letterHeight = RENDERED_LETTER_HEIGHT,
  letterSpacing = 1 // Default spacing if not provided
}) => {
  const characters = text.split('');

  if (!text.trim()) {
    return (
      <div 
        className="flex flex-wrap items-end p-4 border border-slate-600 rounded-md bg-slate-700/50 min-h-[120px] text-slate-500 italic"
        style={{ lineHeight: `${letterHeight}px` }}
        aria-label={es.textRendererPlaceholder}
      >
        {es.textRendererPlaceholder}
      </div>
    );
  }

  return (
    <div 
        className="flex flex-wrap items-end p-4 border border-slate-600 rounded-md bg-slate-700/50 min-h-[120px]"
        style={{ lineHeight: `${letterHeight}px` }}
        aria-label={es.yourHandwrittenText}
    >
      {characters.map((char, index) => {
        const upperChar = char.toUpperCase();
        const imageDataUrl = alphabet[upperChar];

        if (char === ' ') {
          return <span key={`space-${index}`} style={{ width: `${letterHeight * 0.4}px`, display: 'inline-block' }}></span>;
        }
        if (char === '\n') {
          return <div key={`newline-${index}`} className="w-full h-0 basis-full"></div>;
        }

        if (imageDataUrl) {
          return (
            <img
              key={`${char}-${index}`}
              src={imageDataUrl}
              alt={char}
              className="inline-block object-contain"
              style={{ 
                height: `${letterHeight}px`, 
                maxHeight: `${letterHeight}px`, 
                marginRight: `${letterSpacing}px`, // Apply letterSpacing
                verticalAlign: 'bottom' 
              }}
            />
          );
        } else {
          // Fallback for characters not in the custom alphabet
          return (
            <span
              key={`${char}-${index}-fallback`}
              className="inline-block text-slate-300"
              style={{
                fontSize: `${letterHeight * 0.9}px`,
                height: `${letterHeight}px`,
                lineHeight: `${letterHeight}px`,
                marginRight: `${letterSpacing}px`, // Apply letterSpacing
                fontFamily: 'monospace',
                verticalAlign: 'bottom'
              }}
            >
              {char}
            </span>
          );
        }
      })}
    </div>
  );
};