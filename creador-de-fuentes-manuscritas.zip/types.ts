
export interface DrawnAlphabet {
  [key: string]: string; // Letter (e.g., 'A') -> ImageDataURL (base64 string)
}

// Enum for view states, though not strictly used with the current App.tsx state management
export enum AppView {
  DRAWING = 'drawing',
  COMPOSING = 'composing',
}
